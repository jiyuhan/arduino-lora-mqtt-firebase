// project-specific definitions for otaa sensor
#define CFG_us915 1
#define CFG_sx1276_radio 1
//#define LMIC_USE_INTERRUPTS
